package com.jayme.compensation;

public enum CommissionType {

	SALARY, BONUS, COMMISSION, ALLOWANCE, ADJUSTMENT;
}
