package com.jayme;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmploymentSystemProgramApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmploymentSystemProgramApplication.class, args);
	}

}
